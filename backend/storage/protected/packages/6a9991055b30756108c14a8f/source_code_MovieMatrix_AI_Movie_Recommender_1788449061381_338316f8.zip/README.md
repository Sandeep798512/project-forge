# 🎬 MovieMatrix – AI Movie Recommender & Discovery Platform

MovieMatrix is a commercial-grade, full-stack AI movie recommender and discovery web application. It features a dark glassmorphism UI, secure `.env` API proxy server built with Node.js & Express, AI mood-based recommendation engine, real-time IMDb search auto-complete, YouTube trailer preview modal, and Watchlist drawer persistence.

---

## ⚡ Quick Start Guide (VS Code)

1. **Install Node.js**: Download & install from [nodejs.org](https://nodejs.org).
2. **Open Project**: Open this folder in VS Code (`File -> Open Folder`).
3. **Open Terminal**: Press `Ctrl + ~` or go to `Terminal -> New Terminal`.
4. **Install Dependencies**:
   ```bash
   npm install
   ```
5. **Start Server**:
   ```bash
   npm start
   ```
6. **Open Browser**: Visit **`http://localhost:3000`**

For complete step-by-step instructions and troubleshooting, see [SETUP_GUIDE.md](SETUP_GUIDE.md).

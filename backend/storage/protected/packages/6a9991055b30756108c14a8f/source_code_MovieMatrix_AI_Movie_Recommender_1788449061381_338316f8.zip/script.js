/* ==========================================================================
   🎬 MovieMatrix 2.0 – Commercial Grade Application Logic
   ========================================================================== */

// Fallback direct API key if running without backend server
const STATIC_API_KEY = "956a86";
let isServerMode = false;
let apiCache = new Map();
let debounceTimer = null;
let currentSearchQuery = "";
let watchlist = JSON.parse(localStorage.getItem('moviematrix_watchlist')) || [];

// DOM Elements
const input = document.getElementById("movieInput");
const searchBtn = document.getElementById("searchBtn");
const clearSearchBtn = document.getElementById("clearSearchBtn");
const suggestionsBox = document.getElementById("suggestions");
const serverStatusEl = document.getElementById("server-status");
const watchlistCountEl = document.getElementById("watchlist-count");

// Containers
const aiGridContainer = document.getElementById("ai-recommendations-grid");
const searchResultSection = document.getElementById("search-result-section");
const searchMovieDetails = document.getElementById("search-movie-details");
const recommendContainer = document.getElementById("recommend-container");
const recommendTitle = document.getElementById("recommend-title");
const searchTitle = document.getElementById("search-title");
const homeFeed = document.getElementById("home-feed");

const nowPlayingContainer = document.getElementById("now-playing");
const indiaMoviesContainer = document.getElementById("india-movies");
const topImdbContainer = document.getElementById("top-imdb");

/* ================= INITIALIZATION ================= */
window.addEventListener("DOMContentLoaded", async () => {
    await checkBackendServer();
    updateWatchlistCount();
    initTypewriterEffect();
    
    // Load home sections
    loadAIRecommendations('mind-bending');
    loadNowPlaying();
    loadIndianMovies();
    loadTopIMDb();

    setupEventListeners();
});

/* ================= TYPEWRITER EFFECT ================= */
function initTypewriterEffect() {
    const typingElement = document.getElementById("typing-text");
    if (!typingElement) return;

    const phrases = [
        "Obsess Over",
        "Love Forever",
        "Binge Tonight",
        "Never Forget",
        "Recommend Next",
        "Watch Again"
    ];

    let phraseIndex = 0;
    let charIndex = phrases[0].length;
    let isDeleting = true;
    let typingSpeed = 100;

    function type() {
        const currentPhrase = phrases[phraseIndex];

        if (isDeleting) {
            charIndex--;
            typingSpeed = 45;
        } else {
            charIndex++;
            typingSpeed = 90;
        }

        typingElement.textContent = currentPhrase.substring(0, charIndex);

        if (!isDeleting && charIndex === currentPhrase.length) {
            // Pause when full phrase is typed
            typingSpeed = 2200;
            isDeleting = true;
        } else if (isDeleting && charIndex === 0) {
            // Switch to next phrase when fully deleted
            isDeleting = false;
            phraseIndex = (phraseIndex + 1) % phrases.length;
            typingSpeed = 400;
        }

        setTimeout(type, typingSpeed);
    }

    setTimeout(type, 2200);
}

/* ================= CHECK BACKEND / .ENV STATUS ================= */
async function checkBackendServer() {
    try {
        const res = await fetch('/api/config');
        if (res.ok) {
            const data = await res.json();
            if (data.status === 'ok') {
                isServerMode = true;
                serverStatusEl.innerHTML = `<span class="status-dot"></span> <span class="status-text">.env API Active</span>`;
                serverStatusEl.style.borderColor = 'rgba(34, 197, 94, 0.4)';
                return;
            }
        }
    } catch (e) {
        // Static mode fallback
    }

    isServerMode = false;
    serverStatusEl.innerHTML = `<span class="status-dot" style="background: #f59e0b; box-shadow: 0 0 8px #f59e0b;"></span> <span class="status-text" style="color: #f59e0b;">Static API Mode</span>`;
    serverStatusEl.title = "Running in direct API mode using static key.";
}

/* ================= API CALL PROXY / FALLBACK WRAPPER ================= */
async function fetchFromApi(endpoint, fallbackUrl) {
    const cacheKey = isServerMode ? endpoint : fallbackUrl;
    if (apiCache.has(cacheKey)) {
        return apiCache.get(cacheKey);
    }

    try {
        const url = isServerMode ? endpoint : fallbackUrl;
        const res = await fetch(url);
        const data = await res.json();
        
        if (data && data.Response !== "False") {
            apiCache.set(cacheKey, data);
        }
        return data;
    } catch (err) {
        console.error("API Fetch Error:", err);
        return { Response: "False", Error: "Network error" };
    }
}

/* ================= EVENT LISTENERS ================= */
function setupEventListeners() {
    // Search button click
    searchBtn.addEventListener("click", () => handleSearchSubmit());
    
    // Enter key submit
    input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") handleSearchSubmit();
    });

    // Auto-complete debounce search
    input.addEventListener("input", () => {
        const query = input.value.trim();
        clearSearchBtn.style.display = query.length > 0 ? "block" : "none";

        clearTimeout(debounceTimer);
        if (query.length < 2) {
            suggestionsBox.style.display = "none";
            return;
        }

        debounceTimer = setTimeout(() => fetchSuggestions(query), 280);
    });

    // Clear search
    clearSearchBtn.addEventListener("click", () => {
        input.value = "";
        clearSearchBtn.style.display = "none";
        suggestionsBox.style.display = "none";
        input.focus();
    });

    // Hide suggestions on click outside
    document.addEventListener("click", (e) => {
        if (!e.target.closest(".search-wrapper")) {
            suggestionsBox.style.display = "none";
        }
    });
}

/* ================= AUTO-SUGGESTIONS ================= */
async function fetchSuggestions(query) {
    const endpoint = `/api/movies/search?s=${encodeURIComponent(query)}`;
    const fallbackUrl = `https://www.omdbapi.com/?apikey=${STATIC_API_KEY}&s=${encodeURIComponent(query)}`;
    
    const data = await fetchFromApi(endpoint, fallbackUrl);
    
    if (!data || data.Response === "False" || !data.Search) {
        suggestionsBox.style.display = "none";
        return;
    }

    suggestionsBox.innerHTML = "";
    data.Search.slice(0, 5).forEach(movie => {
        const item = document.createElement("div");
        item.className = "suggestion-item";
        item.innerHTML = `
            <span class="suggestion-title">${escapeHtml(movie.Title)}</span>
            <span class="suggestion-year">${movie.Year}</span>
        `;
        item.onclick = () => {
            input.value = movie.Title;
            suggestionsBox.style.display = "none";
            executeSearch(movie.Title);
        };
        suggestionsBox.appendChild(item);
    });

    suggestionsBox.style.display = "block";
}

/* ================= SEARCH EXECUTION ================= */
function handleSearchSubmit() {
    const query = input.value.trim();
    if (!query) return;
    suggestionsBox.style.display = "none";
    executeSearch(query);
}

function quickSearch(query) {
    input.value = query;
    clearSearchBtn.style.display = "block";
    executeSearch(query);
}

async function executeSearch(query) {
    currentSearchQuery = query;
    showHomeFeed(false);
    searchResultSection.style.display = "block";
    searchTitle.innerHTML = `<i class="fa-solid fa-magnifying-glass"></i> Results for "${escapeHtml(query)}"`;

    showSkeletons(searchMovieDetails, 1, 'feature');
    showSkeletons(recommendContainer, 6);

    // Fetch primary movie detail
    const detailEndpoint = `/api/movies/detail?t=${encodeURIComponent(query)}&plot=full`;
    const detailFallback = `https://www.omdbapi.com/?apikey=${STATIC_API_KEY}&t=${encodeURIComponent(query)}&plot=full`;
    const primaryMovie = await fetchFromApi(detailEndpoint, detailFallback);

    if (primaryMovie && primaryMovie.Response !== "False") {
        renderFeatureMovieCard(primaryMovie, searchMovieDetails);
    } else {
        searchMovieDetails.innerHTML = `
            <div class="movie-feature-card" style="text-align:center;">
                <p>No exact match found for "${escapeHtml(query)}". Check out related movies below!</p>
            </div>
        `;
    }

    // Fetch related recommendations list
    const searchEndpoint = `/api/movies/search?s=${encodeURIComponent(query)}`;
    const searchFallback = `https://www.omdbapi.com/?apikey=${STATIC_API_KEY}&s=${encodeURIComponent(query)}`;
    const searchResults = await fetchFromApi(searchEndpoint, searchFallback);

    recommendTitle.innerText = `Related Movies & Recommendations`;
    recommendContainer.innerHTML = "";

    if (searchResults && searchResults.Search) {
        const seen = new Set();
        searchResults.Search.forEach(movie => {
            if (seen.has(movie.imdbID)) return;
            seen.add(movie.imdbID);
            createMovieCard(movie, recommendContainer);
        });
    } else {
        recommendContainer.innerHTML = `<p style="color: var(--text-muted);">No additional recommendations found.</p>`;
    }

    scrollToSection("search-result-section");
}

/* ================= FEATURE MOVIE RENDERER ================= */
function renderFeatureMovieCard(movie, container) {
    const poster = (movie.Poster && movie.Poster !== "N/A") ? movie.Poster : getPosterPlaceholder(movie.Title);
    const inWatchlist = isBookmarked(movie.imdbID);

    container.innerHTML = `
        <div class="movie-feature-card">
            <div class="feature-poster">
                <img src="${poster}" alt="${escapeHtml(movie.Title)}" onerror="this.src='${getPosterPlaceholder(movie.Title)}'">
            </div>
            <div class="feature-details">
                <h2 class="feature-title">${escapeHtml(movie.Title)}</h2>
                <div class="feature-tags">
                    <span class="chip chip-gold">⭐ IMDb ${movie.imdbRating || 'N/A'}</span>
                    <span class="chip">${movie.Year || 'N/A'}</span>
                    <span class="chip">${movie.Rated || 'N/A'}</span>
                    <span class="chip">${movie.Runtime || 'N/A'}</span>
                    <span class="chip">${movie.Genre || 'N/A'}</span>
                </div>
                <p class="feature-plot">${movie.Plot || 'No plot summary available.'}</p>
                <div class="feature-actions">
                    <button class="btn-primary" onclick="openMovieModal('${movie.imdbID}')">
                        <i class="fa-solid fa-play"></i> Watch Trailer & Info
                    </button>
                    <button class="btn-secondary" onclick="toggleWatchlist('${movie.imdbID}', '${escapeHtml(movie.Title)}', '${poster}', '${movie.imdbRating}', '${movie.Year}')">
                        <i class="${inWatchlist ? 'fa-solid' : 'fa-regular'} fa-bookmark"></i> ${inWatchlist ? 'Saved in Watchlist' : 'Add to Watchlist'}
                    </button>
                </div>
            </div>
        </div>
    `;
}

/* ================= AI MOOD RECOMMENDER ================= */
async function selectMood(moodKey, btnEl) {
    document.querySelectorAll(".mood-chip").forEach(c => c.classList.remove("active"));
    if (btnEl) btnEl.classList.add("active");

    await loadAIRecommendations(moodKey);
}

async function loadAIRecommendations(moodKey) {
    showSkeletons(aiGridContainer, 6);

    const endpoint = `/api/movies/recommend?mood=${moodKey}`;
    
    // Static fallback keywords
    const staticMoodKeywords = {
        'mind-bending': ['Inception', 'Interstellar', 'Matrix', 'Shutter Island', 'Tenet', 'Coherence'],
        'action-thriller': ['Mad Max', 'John Wick', 'Gladiator', 'The Dark Knight', 'Top Gun'],
        'feel-good': ['Forrest Gump', '3 Idiots', 'Amelie', 'La La Land', 'Paddington'],
        'dark-mystery': ['Se7en', 'Zodiac', 'Prisoners', 'The Prestige', 'Gone Girl'],
        'sci-fi-epic': ['Dune', 'Blade Runner', 'Avatar', 'Arrival', 'The Martian'],
        'indian-cinema': ['Dangal', 'RRR', '3 Idiots', 'KGF', 'Jawan', 'Baahubali']
    };

    if (isServerMode) {
        const data = await fetchFromApi(endpoint, '');
        if (data && data.Search && data.Search.length > 0) {
            aiGridContainer.innerHTML = "";
            data.Search.forEach(movie => createMovieCard(movie, aiGridContainer, true));
            return;
        }
    }

    // Static mode fetch
    aiGridContainer.innerHTML = "";
    const titles = staticMoodKeywords[moodKey] || staticMoodKeywords['mind-bending'];
    
    for (const title of titles) {
        const fallbackUrl = `https://www.omdbapi.com/?apikey=${STATIC_API_KEY}&t=${encodeURIComponent(title)}`;
        const movie = await fetchFromApi(`/api/movies/detail?t=${encodeURIComponent(title)}`, fallbackUrl);
        if (movie && movie.Response !== "False") {
            createMovieCard(movie, aiGridContainer, true);
        }
    }
}

/* ================= HOME FEED LOADERS ================= */
async function loadNowPlaying() {
    showSkeletons(nowPlayingContainer, 4);
    fetchPresetMovies(["Deadpool", "Oppenheimer", "Dune", "Batman"], nowPlayingContainer);
}

async function loadIndianMovies() {
    showSkeletons(indiaMoviesContainer, 4);
    fetchPresetMovies(["Dangal", "RRR", "3 Idiots", "KGF"], indiaMoviesContainer);
}

async function loadTopIMDb() {
    showSkeletons(topImdbContainer, 4);
    fetchPresetMovies(["The Shawshank Redemption", "The Godfather", "The Dark Knight", "Pulp Fiction"], topImdbContainer);
}

async function fetchPresetMovies(titleArray, container) {
    container.innerHTML = "";
    for (const title of titleArray) {
        const endpoint = `/api/movies/detail?t=${encodeURIComponent(title)}`;
        const fallbackUrl = `https://www.omdbapi.com/?apikey=${STATIC_API_KEY}&t=${encodeURIComponent(title)}`;
        const m = await fetchFromApi(endpoint, fallbackUrl);
        if (m && m.Response !== "False") {
            createMovieCard(m, container, true);
        }
    }
}

/* ================= CARD CREATOR ================= */
function createMovieCard(movie, container, showRating = true) {
    const card = document.createElement("div");
    card.className = "movie-card";
    
    const poster = (movie.Poster && movie.Poster !== "N/A") ? movie.Poster : getPosterPlaceholder(movie.Title);
    const rating = movie.imdbRating || "8.0+";

    card.innerHTML = `
        <div class="poster-wrapper">
            <img src="${poster}" alt="${escapeHtml(movie.Title)}" loading="lazy" onerror="this.src='${getPosterPlaceholder(movie.Title)}'">
            ${showRating ? `<div class="rating-badge">⭐ ${rating}</div>` : ''}
            <div class="card-overlay">
                <button class="overlay-btn"><i class="fa-solid fa-circle-info"></i> View Details</button>
            </div>
        </div>
        <div class="movie-info">
            <h3 class="movie-title">${escapeHtml(movie.Title)}</h3>
            <div class="movie-meta">
                <span>${movie.Year || ''}</span>
                <span>${movie.Type ? capitalize(movie.Type) : 'Movie'}</span>
            </div>
        </div>
    `;

    card.onclick = () => openMovieModal(movie.imdbID || movie.Title, !movie.imdbID);
    container.appendChild(card);
}

/* ================= MOVIE DETAIL MODAL & YOUTUBE TRAILER ================= */
async function openMovieModal(idOrTitle, isTitle = false) {
    const modal = document.getElementById("movie-modal");
    const modalBody = document.getElementById("modal-content-body");

    modalBody.innerHTML = `
        <div style="padding: 40px; text-align: center;">
            <i class="fa-solid fa-spinner fa-spin" style="font-size: 2.5rem; color: var(--accent-green);"></i>
            <p style="margin-top: 15px;">Loading movie details & trailer...</p>
        </div>
    `;

    modal.classList.add("active");

    const param = isTitle ? `t=${encodeURIComponent(idOrTitle)}` : `i=${encodeURIComponent(idOrTitle)}`;
    const endpoint = `/api/movies/detail?${param}&plot=full`;
    const fallbackUrl = `https://www.omdbapi.com/?apikey=${STATIC_API_KEY}&${param}&plot=full`;

    const movie = await fetchFromApi(endpoint, fallbackUrl);

    if (!movie || movie.Response === "False") {
        modalBody.innerHTML = `<p style="padding: 30px;">Failed to load movie details.</p>`;
        return;
    }

    const poster = (movie.Poster && movie.Poster !== "N/A") ? movie.Poster : getPosterPlaceholder(movie.Title);
    const inWatchlist = isBookmarked(movie.imdbID);

    // Embed YouTube search trailer
    const trailerSearchQuery = encodeURIComponent(`${movie.Title} ${movie.Year || ''} Official Trailer`);
    const trailerEmbedUrl = `https://www.youtube.com/embed?listType=search&list=${trailerSearchQuery}&autoplay=1`;

    modalBody.innerHTML = `
        <div class="modal-grid">
            <div>
                <img src="${poster}" alt="${escapeHtml(movie.Title)}" style="width:100%; border-radius:14px;" onerror="this.src='${getPosterPlaceholder(movie.Title)}'">
                <button class="btn-secondary" style="width:100%; margin-top:14px; justify-content:center;" onclick="toggleWatchlist('${movie.imdbID}', '${escapeHtml(movie.Title)}', '${poster}', '${movie.imdbRating}', '${movie.Year}')">
                    <i class="${inWatchlist ? 'fa-solid' : 'fa-regular'} fa-bookmark"></i> ${inWatchlist ? 'Saved' : 'Add to Watchlist'}
                </button>
            </div>
            <div>
                <h2 style="font-family:var(--font-heading); font-size:2rem; margin-bottom:10px;">${escapeHtml(movie.Title)}</h2>
                <div class="feature-tags">
                    <span class="chip chip-gold">⭐ IMDb ${movie.imdbRating}</span>
                    <span class="chip">${movie.Year}</span>
                    <span class="chip">${movie.Rated}</span>
                    <span class="chip">${movie.Runtime}</span>
                </div>
                <p style="color:var(--text-secondary); line-height:1.6; margin:15px 0;">${movie.Plot}</p>
                <p><strong>Genre:</strong> ${movie.Genre}</p>
                <p><strong>Director:</strong> ${movie.Director}</p>
                <p><strong>Actors:</strong> ${movie.Actors}</p>
                <p style="margin-top:6px;"><strong>Awards:</strong> ${movie.Awards}</p>

                <div style="margin-top:20px;">
                    <h4 style="margin-bottom:8px;"><i class="fa-brands fa-youtube" style="color:#red;"></i> Official Trailer Preview</h4>
                    <div class="modal-trailer-box">
                        <iframe src="${trailerEmbedUrl}" allowfullscreen title="Trailer"></iframe>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function closeMovieModal() {
    const modal = document.getElementById("movie-modal");
    modal.classList.remove("active");
    // Clear iframe so audio stops
    document.getElementById("modal-content-body").innerHTML = "";
}

function closeModalOnOverlay(e) {
    if (e.target.classList.contains("modal-overlay")) {
        closeMovieModal();
    }
}

/* ================= WATCHLIST PERSISTENCE ================= */
function isBookmarked(imdbID) {
    return watchlist.some(item => item.id === imdbID);
}

function toggleWatchlist(id, title, poster, rating, year) {
    const index = watchlist.findIndex(item => item.id === id);
    if (index > -1) {
        watchlist.splice(index, 1);
        showToast(`Removed "${title}" from Watchlist`);
    } else {
        watchlist.push({ id, title, poster, rating, year });
        showToast(`Added "${title}" to Watchlist!`);
    }

    localStorage.setItem('moviematrix_watchlist', JSON.stringify(watchlist));
    updateWatchlistCount();
    renderWatchlistItems();
}

function updateWatchlistCount() {
    if (watchlistCountEl) {
        watchlistCountEl.innerText = watchlist.length;
    }
}

function toggleWatchlistDrawer() {
    const drawer = document.getElementById("watchlist-drawer");
    drawer.classList.toggle("active");
    if (drawer.classList.contains("active")) {
        renderWatchlistItems();
    }
}

function closeDrawerOnOverlay(e) {
    if (e.target.classList.contains("drawer-overlay")) {
        toggleWatchlistDrawer();
    }
}

function renderWatchlistItems() {
    const container = document.getElementById("watchlist-items");
    if (watchlist.length === 0) {
        container.innerHTML = `<p style="text-align:center; color:var(--text-muted); margin-top:40px;">Your Watchlist is currently empty.</p>`;
        return;
    }

    container.innerHTML = "";
    watchlist.forEach(item => {
        const div = document.createElement("div");
        div.className = "watchlist-item";
        div.innerHTML = `
            <img src="${item.poster}">
            <div class="watchlist-info">
                <h4>${escapeHtml(item.title)}</h4>
                <p>⭐ ${item.rating || 'N/A'} • ${item.year}</p>
            </div>
            <button class="remove-item-btn" onclick="toggleWatchlist('${item.id}', '${escapeHtml(item.title)}')">&times;</button>
        `;
        div.onclick = (e) => {
            if (!e.target.classList.contains("remove-item-btn")) {
                toggleWatchlistDrawer();
                openMovieModal(item.id);
            }
        };
        container.appendChild(div);
    });
}

function clearWatchlist() {
    if (confirm("Are you sure you want to clear your entire watchlist?")) {
        watchlist = [];
        localStorage.setItem('moviematrix_watchlist', JSON.stringify(watchlist));
        updateWatchlistCount();
        renderWatchlistItems();
        showToast("Watchlist cleared");
    }
}

/* ================= UTILITY & HELPERS ================= */
function showHomeFeed(show = true) {
    homeFeed.style.display = show ? "block" : "none";
    if (show) searchResultSection.style.display = "none";
}

function resetToHome() {
    input.value = "";
    clearSearchBtn.style.display = "none";
    suggestionsBox.style.display = "none";
    showHomeFeed(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function scrollToSection(sectionId) {
    const el = document.getElementById(sectionId);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function showSkeletons(container, count = 4, type = 'card') {
    container.innerHTML = "";
    for (let i = 0; i < count; i++) {
        const div = document.createElement("div");
        div.className = type === 'card' ? "skeleton skeleton-card" : "skeleton";
        if (type === 'feature') div.style.height = "250px";
        container.appendChild(div);
    }
}

function getPosterPlaceholder(title) {
    return `https://via.placeholder.com/300x450/161c2a/22c55e?text=${encodeURIComponent(title || 'Movie')}`;
}

function showToast(msg) {
    const container = document.getElementById("toast-container");
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${msg}`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function capitalize(text) {
    if (!text) return "";
    return text.charAt(0).toUpperCase() + text.slice(1);
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>"']/g, function(m) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        }[m];
    });
}
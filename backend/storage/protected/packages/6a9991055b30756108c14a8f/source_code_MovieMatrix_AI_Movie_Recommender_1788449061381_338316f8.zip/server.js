require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const DEFAULT_PORT = process.env.PORT || 3000;
const API_KEY = process.env.OMDB_API_KEY || '956a86';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Health & Config Check
app.get('/api/config', (req, res) => {
  res.json({
    status: 'ok',
    mode: 'server',
    hasApiKey: Boolean(API_KEY)
  });
});

// API Proxy - Search movies by keyword
app.get('/api/movies/search', async (req, res) => {
  try {
    const { s, page = 1, type = '' } = req.query;
    if (!s) {
      return res.status(400).json({ Response: "False", Error: "Search parameter 's' is required." });
    }

    const omdbUrl = `https://www.omdbapi.com/?apikey=${API_KEY}&s=${encodeURIComponent(s)}&page=${page}&type=${type}`;
    const response = await fetch(omdbUrl);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error('Error fetching from OMDB API search:', error);
    res.status(500).json({ Response: "False", Error: "Failed to fetch movie data from server." });
  }
});

// API Proxy - Get detailed movie info by Title or IMDb ID
app.get('/api/movies/detail', async (req, res) => {
  try {
    const { t, i, plot = 'full' } = req.query;
    if (!t && !i) {
      return res.status(400).json({ Response: "False", Error: "Provide parameter 't' (title) or 'i' (imdbID)." });
    }

    const param = i ? `i=${encodeURIComponent(i)}` : `t=${encodeURIComponent(t)}`;
    const omdbUrl = `https://www.omdbapi.com/?apikey=${API_KEY}&${param}&plot=${plot}`;
    const response = await fetch(omdbUrl);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    console.error('Error fetching movie detail:', error);
    res.status(500).json({ Response: "False", Error: "Failed to fetch movie detail." });
  }
});

// API Proxy - AI Recommended movies based on mood/genre presets
app.get('/api/movies/recommend', async (req, res) => {
  try {
    const { mood = 'mind-bending' } = req.query;

    const moodQueries = {
      'mind-bending': ['Inception', 'Interstellar', 'Matrix', 'Shutter Island', 'Tenet', 'Coherence', 'Dark'],
      'action-thriller': ['Mad Max', 'John Wick', 'Gladiator', 'The Dark Knight', 'Top Gun', 'Mission Impossible'],
      'feel-good': ['Forrest Gump', 'Amelie', '3 Idiots', 'La La Land', 'Paddington', 'Little Miss Sunshine'],
      'dark-mystery': ['Se7en', 'Zodiac', 'Prisoners', 'The Prestige', 'Gone Girl', 'Silence of the Lambs'],
      'sci-fi-epic': ['Dune', 'Blade Runner', 'Avatar', 'Star Wars', 'Arrival', 'The Martian'],
      'indian-cinema': ['Dangal', 'RRR', '3 Idiots', 'KGF', 'Jawan', 'Baahubali', 'Lagaan']
    };

    const queryList = moodQueries[mood] || moodQueries['mind-bending'];
    
    // Pick movies to fetch details in parallel
    const selectedTitles = queryList.slice(0, 6);
    const moviePromises = selectedTitles.map(title =>
      fetch(`https://www.omdbapi.com/?apikey=${API_KEY}&t=${encodeURIComponent(title)}`)
        .then(res => res.json())
        .catch(() => null)
    );

    const movies = (await Promise.all(moviePromises)).filter(m => m && m.Response !== 'False');
    res.json({ Response: "True", Search: movies, mood });
  } catch (error) {
    console.error('Error fetching recommendations:', error);
    res.status(500).json({ Response: "False", Error: "Failed to load AI recommendations." });
  }
});

function startServer(port) {
  const server = app.listen(port, () => {
    console.log(`===================================================`);
    console.log(`🎬 MovieMatrix Server running on http://localhost:${port}`);
    console.log(`🔑 OMDB API Key loaded securely from .env file`);
    console.log(`===================================================`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`⚠️ Port ${port} is in use, retrying on port ${port + 1}...`);
      startServer(port + 1);
    } else {
      console.error('Server error:', err);
    }
  });
}

startServer(Number(DEFAULT_PORT));
